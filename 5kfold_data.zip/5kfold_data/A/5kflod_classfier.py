import pandas as pd 
from sklearn.model_selection import KFold
import os,sys,csv


# 保存TSV文件的函数
def save_tsv_file(file_path, data):
    data.to_csv(file_path, sep='\t', index=False)

df1 = pd.read_csv('i2om_old_data/train.tsv', delimiter='\t')
df2 = pd.read_csv('data_5kflod/old_data/train/LGBM_435_feature')
number = {'0':range(1,df1.shape[0]+1)}
df3 = pd.DataFrame(number)
# print(df3)
df = pd.concat([df3,df1,df2],axis=1)
# print(df)
# sys.exit()

# 定义五折交叉验证
kf = KFold(n_splits=5, shuffle=True, random_state=42)
# 保存每一折的训练集和验证集
for fold, (train_index, val_index) in enumerate(kf.split(df)):
    train_set = df.iloc[train_index]
    val_set = df.iloc[val_index]
    # print(train_set)
    # sys.exit()
    folder_path = f'data_5kflod/5kflod_data/{fold+1}'
    os.makedirs(folder_path)

    # 保存训练集和测试集到 TSV 文件
    save_tsv_file(f"{folder_path}/train.tsv", train_set)
    save_tsv_file(f"{folder_path}/test.tsv", val_set)