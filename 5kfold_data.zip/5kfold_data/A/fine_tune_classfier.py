import os
import pandas as pd 

# 保存TSV文件的函数
def save_tsv_file(file_path, data):
    data.to_csv(file_path, sep='\t', index=False)

folder_path = "5kflod_data"
file_names = os.listdir(folder_path)

# 循环遍历文件夹中的文件
for file_name in file_names:
    df1 = pd.read_csv(f'5kflod_data/{file_name}/train.tsv', sep='\t').iloc[:,1:3]
    df1 = df1.sample(frac=1).reset_index(drop=True)
    df2 = pd.read_csv(f'5kflod_data/{file_name}/test.tsv', sep='\t').iloc[:,1:3]
    folder_path2 = f'fine_tune_data/{file_name}'
    os.makedirs(folder_path2)
    save_tsv_file(f"{folder_path2}/train.tsv",df1)
    save_tsv_file(f"{folder_path2}/test.tsv",df2)
