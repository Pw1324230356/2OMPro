import os

def split_sequence(sequence, kmer_length):
    kmers = [sequence[i:i + kmer_length].replace('U','T') for i in range(0, len(sequence) - kmer_length + 1)]
    return kmers

def write_kmers_to_txt(sequence, kmer_length,file):


    kmers = split_sequence(sequence, kmer_length)
    length=len(kmers)
    for i in range(length):
        if i!=(length-1):
            file.write(f"{kmers[i]} ")
        else:
            file.write(f"{kmers[i]}\n")



# file_path = 'i2om_old_data'
# # for file_name in os.listdir(file_path):
# #     a = file_name

# path1 = "{file_path}/{a}/train.tsv"
# path2 = f"{file_path}/{a}/test.tsv"
#     path = f'/home/wpeng/ensemble_1_3_5/i2om_1mer_data/{a}'
#     os.makedirs(path)


for j in [1,3,5]:
    for i in range(1,6):
        folder_path1 = f"1_3_5mer_fine_tune_data/{i}/{j}mer"
        if not os.path.exists(folder_path1):
            # 如果不存在，创建文件夹
            os.makedirs(folder_path1)
            print(f"Folder '{folder_path1}' created.")
        else:
            # 如果存在，跳过
            print(f"Folder '{folder_path1}' already exists. Skipping creation.")

        with open(f"fine_tune_data/{i}/train.tsv", "r") as tsv_file, open(
                    f"1_3_5mer_fine_tune_data/{i}/{j}mer/train.tsv", "w") as fasta_file:
                lines = tsv_file.readlines()
                for line in lines[1:]:
                    fields = line.strip().split("\t")
                    if len(fields) == 2:
                        sequence_label = fields[0]
                        fasta_file.write(f"{sequence_label}\t")
                        sequence_data = fields[1]
                        write_kmers_to_txt(sequence_data, j , fasta_file)

        with open(f"fine_tune_data/{i}/test.tsv", "r") as tsv_file, open(
                    f"1_3_5mer_fine_tune_data/{i}/{j}mer/test.tsv", "w") as fasta_file:
                lines = tsv_file.readlines()
                for line in lines[1:]:
                    fields = line.strip().split("\t")
                    if len(fields) == 2:
                        sequence_label = fields[0]
                        fasta_file.write(f"{sequence_label}\t")
                        sequence_data = fields[1]
                        write_kmers_to_txt(sequence_data, j, fasta_file)